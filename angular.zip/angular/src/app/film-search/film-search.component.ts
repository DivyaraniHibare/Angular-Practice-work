import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { FilmServiceService } from '../service/film-service.service';

@Component({
  selector: 'app-film-search',
  templateUrl: './film-search.component.html',
  styleUrls: ['./film-search.component.scss']
})
export class FilmSearchComponent implements OnInit{

  constructor(private service :FilmServiceService,private router: Router) { }
  
  FormSubmit=false;

  ngOnInit(): void {
  }

  @Output() loggedIn: EventEmitter<any> = new EventEmitter<any>();

  addNewTask(task: any): void {
    this.loggedIn.emit(task);
  }
  
  searchMovie!: string;


  searchFilms(){
    if(this.searchMovie!==undefined)
    {this.service.search(this.searchMovie).subscribe(
      (data:any)=>{
        this.router.navigateByUrl("/film");
        this.service.films=data;
        this.FormSubmit=true;
        console.log(data)
      }
    )}
  }

}
