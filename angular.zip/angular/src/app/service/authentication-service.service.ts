import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { LoginRequest } from '../models/authentication/login-request';
import { MovieResponse } from '../models/authentication/movie-response';
import { RegistrationRequest } from '../models/authentication/registration-request';
import { UserResponse } from '../models/authentication/user-response';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationServiceService {

  

  constructor(private router: Router,private httpClient: HttpClient) { }

  token: string | null = null;

  

  get loggedIn(): boolean {
    return this.token != null
  }

  logOut(): void {
    this.router.navigateByUrl('/login')
  }

  private baseUrl = 'https://vue-js-backend.herokuapp.com/user'

  
  login(loginRequest: LoginRequest): Observable<UserResponse> {
    return this.httpClient.post<UserResponse>(this.baseUrl + '/login', loginRequest);
  }
  
  register(regRequest: RegistrationRequest): Observable<UserResponse> {
    const registrationRequest = new RegistrationRequest(
      regRequest.email,
      regRequest.password,
      regRequest.firstname,
      regRequest.lastname
      
    )
    return this.httpClient.post<UserResponse>(this.baseUrl + '/register', registrationRequest)
  }

  

}


